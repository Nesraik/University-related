/*
Bubble Sort (Ascending)

21 5 56 90 42 12

-First Cycle

Compare first two element
since 21 > 5
swap 21 and 5

5 21 56 90 42 12
compare 21 and 56
since 21 < 56
no need to swap

5 21 56 90  42 12
compare 56 and 90
since 56<90
no need to swap

5 21 56 90 42
since 90 >42
swap 90 and 42

5 21 56 42 90 

-2nd Cycle

5 21 56 42 90
compare 21 and 56
since 21<56
no need to swap

5 21 56 42 90
compare 56 and 42
since 56>42
swap 56 and 42

5 21 42 56 90
compare 56 and 90
since 56<90
no need to swap

-3rd cycle
5 21 42 56 90
Compare 42 and 56
since 42<56
no need to swap

5 21 42 56 90
comprare 56 and 90
since 56<90
no need to swap

-4th Cycle
compare 56 and 90
since 56<90
no need to swap



