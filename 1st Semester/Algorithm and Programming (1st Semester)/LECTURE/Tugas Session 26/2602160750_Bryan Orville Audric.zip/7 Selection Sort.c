/*

Selection sort

21 5 56 90 42 12

First loop

find the smallest element out of all numbers in the array

5 is the smallest number

swap 5 with the number in the first element of array

swap 5 and 21

5 21 56 90 42 12

second loop

find the second smallest element out of all numbers in the array

12 is the second smallest number

swap 12 with the number in the second element of array

swap 12 and 21

5 12 56 90 42 21

third loop

find the third smallest element out of all numbers in the array

21 is the third smallest number

swap 21 with the number in the third element of array

swap 21 and 56

5 12 21 90 42 56

fourth loop

find the fourth smallest element out of all numbers in the array

42 is the fourth smallest number

swap 42 with the number in the fourth element of array

swap 42 and 90

5 12 21 42 90 56

fifth loop

find the fifth smallest element out of all numbers in the array

56 is the fifth smallest number

swap 56 with the number in the fifth element of array

swap 56 and 90

5 12 21 42 56 90





