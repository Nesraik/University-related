/*
In C, You cant have two function with the same name at all.
In C++, it's entirely possible as long as the function function signature is different.
*/
