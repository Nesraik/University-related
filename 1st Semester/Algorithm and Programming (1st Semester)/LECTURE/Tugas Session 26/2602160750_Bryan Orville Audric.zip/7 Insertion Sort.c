/*
Insertion Sort

-First cycle
21 5 56 90 42 12

compare 21 and 5
21 > 5
swap 21 and 5

-2nd Cycle
5 21 56 90 42 12

compare 21 and 56
21 < 56
no need to swap

-3rd Cycle
5 21 56 90 42 12

compare 56 and 90
56<90
no need to swap

-4th Cycle
5 21 56 90 42 12

compare 90 and 42
since  90>42
swap 42 and 90

5 21 56 42 90 12

compare 42 and 56
since 56>42
swap 56 and 42

-5th Cycle
5 21 42 56 90 12

compare 90 and 12
since 90>12
swap 90 and 12
no need to swap

5 21 42 56 12 90

compare 56 and 12
since 56>12
swap 56 and 12

5 21 42 12 56 90
compare 42>12
since 42>12
swap 42 and 12

5 21 12 42 56 90
compare 21 and 12
since 21>12
swap 21 and 12

5 12 21 42 56 90

compare 5 and 12
since  12>5
no need to swap

5 12 21 42 56 90
*/









