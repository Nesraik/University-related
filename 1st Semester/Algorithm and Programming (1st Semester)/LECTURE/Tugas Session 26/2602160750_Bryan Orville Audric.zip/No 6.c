#include<stdio.h>

struct identityCard{
		char NIK[17];
		char name[100];
		char birthPlace[100];
		struct dateOfBirth[100];
		char gender[20];
		char bloodType[3];
		char address[100];
		char RT[4];
		char RW[4];
		char kelurahan[100];
		char kecamatan[100];
		char religion[20];
		char status[100];
		char job[100];
		char citizenship[4];
		char belakuHingga[100];
	};
	
int main(){
	struct identityCard KTP;
	return 0;
}


