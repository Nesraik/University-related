/*
Global Variable is a variable declared outisde a function
Local Variable is a variable declared inside a function
*/
