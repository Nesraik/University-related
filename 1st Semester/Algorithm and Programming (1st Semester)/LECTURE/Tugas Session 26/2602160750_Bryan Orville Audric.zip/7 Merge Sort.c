/*

Merge sort

21 5 56 90 42 12

split into two array

21 5 56                          90 42 12
split into two aray              split into two array

21 5                               56                       90 42                                12
split into two array										split into two array

21         5                      56                        90                  42                12

compare and merge


5 21        56                                              42 90                     12

compare and merge

5 21 56                   12 42 90

compare and merge

5 12 21 42 56 90

*/
