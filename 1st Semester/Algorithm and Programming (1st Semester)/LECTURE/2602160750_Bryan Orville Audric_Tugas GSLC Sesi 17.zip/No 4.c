//No 4

_LINE_
/*
a preprocessor macro that expands/converts the current line number in the source file as an integer*/
_FILE_
/*
a preprocessor macro that is used to get the path to the current file(source file)*/
_DATE_
/*
a preprocessor macro that is used to get the date at which the program is compiled
date is in format of month date year*/
_TIME_
/*
a preprocessor macro that is used to get the time at which the program is complied
Time is in format of hour minute second*/
