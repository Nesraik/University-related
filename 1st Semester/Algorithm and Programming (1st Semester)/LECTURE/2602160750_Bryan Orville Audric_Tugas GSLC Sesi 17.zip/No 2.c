//NO 2

void(*ptr[3]) (int)=[function1, function2, function3];
/* 
The data type of the function is Void which doesnt return a value
*ptr[3] is an array of pointer that contain 3 pointer which are function1, function2, and function3
*ptr[3] hold the addresses of function1, function2, funtion3
(int) is the argument that the syntax/function needs
*/
