//NO 3

#Ifdef

.....
#endif
/* its a directive that allows conditional code compilations
the preprocessors check if the mentioned macro (e.g #define debug) exist before including the next code in the process of compilation. 
Only if the name of the macro is defined, the controlled text gets engaged in the output of the preprocessor output. 
These are executed only if the condition gets satisfied. 
*/
#error
/* its a directive to raise an error during complitation, hence terminating the process
*/
#pragma
/* its a directive that is used to turn on or off some features (e.g function)"
#pragma is compliter specific which means its usability vary from from one compiler to the other
*/
#line
/* its a directive that is used to reset the "line" number of code
*/
#ifndef

.....
#endif
/* its a directive that allows conditional code compilations
the preprocessors check if the mentioned macro (e.g #define debug) doesnot exist before including the next code in the process of compilation. 
Only if the name of the macro isnot defined, the controlled text gets engaged in the output of the preprocessor output. 
These are executed only if the condition isnot satisfied. 
*/

