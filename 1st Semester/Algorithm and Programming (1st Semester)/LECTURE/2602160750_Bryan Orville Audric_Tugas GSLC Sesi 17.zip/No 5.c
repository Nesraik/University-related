//NO 5

/*
Advantages of using macro:
-saves a lot of time that is used by the compilter during function calling
-reduces the length of program(syntax)

Disadvantages of using macro:
-they just replace codes, they are not function calling
-program became lengthy if the macros is called several times
*/
