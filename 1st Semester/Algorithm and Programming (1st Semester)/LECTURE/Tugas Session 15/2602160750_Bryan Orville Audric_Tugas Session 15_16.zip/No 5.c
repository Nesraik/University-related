#include <stdio.h>

struct studentscore{
	char nim[11];
	char name[30];
	char subjectcode[5];
	int sks;
	char grade;
};
int main(){
	
	return 0;
}
