
/*
a) Variable name cannot be started with number. Variable such as 1name,1number cannot be used 
b) Variable may consist of more than one word as long as its separated by underscore e.g Two_word, else variable cant consist of more
	than one word. You may also use uppercase letter to show that the variable is more than one word e.g TwoWord.
c) Varible cannot consist of the name of system.

*/
