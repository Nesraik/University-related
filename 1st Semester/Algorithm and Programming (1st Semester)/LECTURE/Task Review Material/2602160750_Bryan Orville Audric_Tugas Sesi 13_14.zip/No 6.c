/*
	The result of z=(x==1)? 5 : 7 if x = 0 is 7
	*/
