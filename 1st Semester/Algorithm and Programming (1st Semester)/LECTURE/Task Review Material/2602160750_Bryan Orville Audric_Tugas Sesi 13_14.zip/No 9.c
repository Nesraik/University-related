/*
The main difference of Do-while and while statement is that Do-while will execute the statement(s) inside for at least one time
regardless of the condition. While dont execute statement if the condition is not fulfilled.
Do while execute statement(s) then check for condition to see if it can keep looping
While checks for condition and if it doesnt fulfill, it wont execute the statement(s) inside.
*/
