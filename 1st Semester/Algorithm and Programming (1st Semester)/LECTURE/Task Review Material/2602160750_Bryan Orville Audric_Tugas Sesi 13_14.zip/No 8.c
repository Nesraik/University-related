/*
Nested if is an if inside of another if e.g:
if(condition){
	if(condition){
	statements
	}
}
it checks the first "if" and if the condition is fulfilled, it checks the condition of "if" inside
*/
