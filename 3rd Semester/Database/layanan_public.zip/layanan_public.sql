-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 07, 2023 at 12:29 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `layanan_public`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `CariComplainPenduduk` (IN `NIKPenduduk` CHAR(16))   BEGIN
SELECT penduduk.NIK AS "NIK Penduduk",penduduk.Nama AS "Nama Penduduk",kategori.Nama_Kategori,complaindetail.Keterangan,complaindetail.Status,pegawai.NamaPegawai AS "Pegawai yang menangani"
FROM penduduk INNER JOIN complainheader ON complainheader.NIK=penduduk.NIK INNER JOIN complaindetail ON complainheader.ComplainHeader_ID=complaindetail.ComplainHeader_ID INNER JOIN pegawai ON complainheader.Pegawai_ID=pegawai.Pegawai_ID INNER JOIN kategori ON complaindetail.Kategori_ID=kategori.Kategori_ID
WHERE complainheader.NIK=NIKPenduduk;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `CariDaftarKomplain` (IN `KotaInput` VARCHAR(12), IN `NamaKategori` VARCHAR(255))   BEGIN
SELECT complainheader.ComplainHeader_ID,complainheader.NIK,kategori.Nama_Kategori,complaindetail.Keterangan,complaindetail.Status, complainheader.Tanggal_Daftar
FROM complainheader INNER JOIN complaindetail ON complainheader.ComplainHeader_ID = complaindetail.ComplainHeader_ID INNER JOIN branch ON complaindetail.Branch_ID = branch.Branch_ID INNER JOIN penduduk ON complainheader.NIK=penduduk.NIK INNER JOIN kategori ON complaindetail.Kategori_ID=kategori.Kategori_ID
WHERE kategori.Nama_Kategori = NamaKategori AND branch.Kota = KotaInput;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateBranchPegawai` (IN `Pegawai_IDIN` CHAR(5), IN `Branch_IDBaru` CHAR(3))   BEGIN
UPDATE pegawai
SET pegawai.Branch_ID= Branch_IDBaru
WHERE pegawai.Pegawai_ID=Pegawai_IDIN;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `UpdateStatusComplain` (IN `NIKPenduduk` CHAR(16), IN `Kategori_IDInput` CHAR(2), IN `StatusBaru` VARCHAR(7))   BEGIN
UPDATE complaindetail
SET complaindetail.Status = StatusBaru
WHERE complaindetail.ComplainHeader_ID=(
    SELECT complainheader.ComplainHeader_ID
    FROM complainheader INNER JOIN complaindetail ON complainheader.ComplainHeader_ID=complaindetail.ComplainHeader_ID
    WHERE complainheader.NIK = NIKPenduduk AND complaindetail.Kategori_ID = Kategori_IDInput
    );
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Stand-in structure for view `balikpapan`
-- (See below for the actual view)
--
CREATE TABLE `balikpapan` (
`ComplainHeader_ID` char(10)
,`NIK` char(16)
,`Nama_Kategori` varchar(255)
,`Keterangan` varchar(255)
,`Status` varchar(50)
,`Branch_ID` char(3)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `bandung`
-- (See below for the actual view)
--
CREATE TABLE `bandung` (
`ComplainHeader_ID` char(10)
,`NIK` char(16)
,`Nama_Kategori` varchar(255)
,`Keterangan` varchar(255)
,`Status` varchar(50)
,`Branch_ID` char(3)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `biaya_pelayanan`
-- (See below for the actual view)
--
CREATE TABLE `biaya_pelayanan` (
`Kota` varchar(255)
,`ComplainHeader_ID` char(10)
,`NIK` char(16)
,`Nama_Kategori` varchar(255)
,`Keterangan` varchar(255)
,`Status` varchar(50)
,`Tanggal_Daftar` date
);

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE `branch` (
  `Branch_ID` char(3) NOT NULL,
  `Kota` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`Branch_ID`, `Kota`) VALUES
('BDO', 'Bandung'),
('BPN', 'Balikpapan'),
('DPS', 'Denpasar'),
('JKT', 'Jakarta'),
('MDN', 'Medan'),
('MKS', 'Makassar'),
('PLB', 'Palembang'),
('SBY', 'Surabaya'),
('SMG', 'Semarang'),
('YGY', 'Yogyakarta');

-- --------------------------------------------------------

--
-- Table structure for table `complaindetail`
--

CREATE TABLE `complaindetail` (
  `ComplainDetail_ID` char(5) NOT NULL,
  `Status` varchar(50) NOT NULL,
  `Keterangan` varchar(255) NOT NULL,
  `Branch_ID` char(3) NOT NULL,
  `Kategori_ID` char(2) NOT NULL,
  `ComplainHeader_ID` char(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `complaindetail`
--

INSERT INTO `complaindetail` (`ComplainDetail_ID`, `Status`, `Keterangan`, `Branch_ID`, `Kategori_ID`, `ComplainHeader_ID`) VALUES
('CD001', 'Closed', 'Keterlambatan dan Ketidaktepatan Transportasi Umum', 'JKT', 'TU', 'CHI3849052'),
('CD002', 'Ongoing', 'Kurangnya Aksesibilitas dan Fasilitas Difabel', 'SBY', 'TU', 'CHI6718294'),
('CD003', 'Closed', 'Tidak Efisienya Rute dan Jaringan Transportasi Umum', 'BDO', 'TU', 'CHI5038172'),
('CD004', 'Ongoing', 'Ketidakpuasaan Petugas pajak dalam pembayaran pajak', 'YGY', 'TP', 'CHI9264871'),
('CD005', 'Ongoing', 'Petugas pajak tidak memberikan bukti pembayaran saya', 'MDN', 'KP', 'CHI7482103'),
('CD006', 'Closed', 'Petugas pajak main Hp saat melayani pelanggan', 'SMG', 'KN', 'CHI1592437'),
('CD007', 'Ongoing', 'Tindakan Diskriminatif oleh Petugas Keamanan', 'MKS', 'TP', 'CHI8023641'),
('CD008', 'Closed', 'Tidak Profesional Petugas Pelayanan Publik', 'PLB', 'TP', 'CHI4359172'),
('CD009', 'Closed', 'Tidak Efisiennya Penanganan Petugas dalam Situasi Darurat', 'BPN', 'TP', 'CHI6971823'),
('CD010', 'Ongoing', 'Keluhan tentang Kurangnya Koordinasi Antarinstansi', 'DPS', 'PU', 'CHI2489371'),
('CD011', 'Closed', 'Keterlambatan Proses Perizinan Usaha', 'JKT', 'PU', 'CHI6103728'),
('CD012', 'Ongoing', 'Keterlambatan dalam pencetakan SIM', 'SBY', 'LP', 'CHI5748092'),
('CD013', 'Closed', 'Lambatnya Respons dalam Penanganan Kejadian Darurat', 'BDO', 'LP', 'CHI3182674'),
('CD014', 'Ongoing', 'Lambatnya Proses Administratif Pemerintah', 'YGY', 'PK', 'CHI9326178'),
('CD015', 'Closed', 'Kurangnya Komunikasi Dokter', 'MDN', 'PK', 'CHI4872051'),
('CD016', 'Ongoing', 'Ketidakjelasan Biaya Pengobatan', 'SMG', 'PK', 'CHI7264810'),
('CD017', 'Closed', 'Keterlambatan dalam pembuatan E-KTP', 'MKS', 'LP', 'CHI1958743'),
('CD018', 'Ongoing', 'Waktu Tunggu yang Lama', 'PLB', 'PK', 'CHI6391748'),
('CD019', 'Closed', 'Biaya pajak yang dianggap terlalu tinggi', 'BPN', 'BP', 'CHI8741203'),
('CD020', 'Ongoing', 'Biaya pelayanan pendidikan yang terus meningkat', 'DPS', 'BP', 'CHI5028316'),
('CD021', 'Closed', 'Biaya pelayanan kebersihan lingkungan yang tinggi', 'JKT', 'BP', 'CHI3187402'),
('CD022', 'Ongoing', 'Petugas pajak meminta bayaran lebih', 'SBY', 'KP', 'CHI6473102'),
('CD023', 'Closed', 'Polisi meminta uang tambahan terhadap keluhan saya', 'BDO', 'KN', 'CHI9204853'),
('CD024', 'Ongoing', 'Polisi tidak merespon laporan kehilangan saya', 'YGY', 'KN', 'CHI5836741'),
('CD025', 'Closed', 'Keterlambatan Transportasi Umum', 'MDN', 'LP', 'CHI3618947'),
('CD026', 'Ongoing', 'Kebijakan Perizinan yang Tidak Fleksibel', 'SMG', 'PU', 'CHI7853419'),
('CD027', 'Closed', 'Kurangnya Akuntabilitas dalam Penanganan Wewenang', 'MKS', 'PW', 'CHI2491873'),
('CD028', 'Ongoing', 'Praktik Penyalahgunaan Wewenang di Lingkungan Pelayanan Publik', 'PLB', 'PW', 'CHI7038251'),
('CD029', 'Closed', 'Tindakan Diskriminatif dalam Penanganan Kasus', 'BPN', 'PW', 'CHI4681253'),
('CD030', 'Ongoing', 'Diskriminasi dan Nepotisme dalam Keputusan Penyaluran Proyek', 'DPS', 'PW', 'CHI3150728'),
('CD031', 'Closed', 'Ketidakpatuhan Petugas terhadap Prosedur', 'JKT', 'PU', 'CHI8741032'),
('CD032', 'Ongoing', 'Ketidakpuasan atas Tingginya Biaya Perizinan Usaha', 'SBY', 'PU', 'CHI2103487'),
('CD033', 'Closed', 'Ketidakpuasan atas Biaya Transportasi Umum yang Terus Naik', 'BDO', 'TU', 'CHI5392176'),
('CD034', 'Ongoing', 'Penyalahgunaan Wewenang oleh Petugas Polisi', 'YGY', 'PW', 'CHI6829154'),
('CD035', 'Closed', 'Kurangnya Fasilitas dan Perawatan Transportasi Umum', 'MDN', 'TU', 'CHI8472139'),
('CD036', 'Ongoing', 'Kurangnya Transparansi Persyaratan Perizinan', 'SMG', 'PU', 'CHI1964237'),
('CD037', 'Closed', 'Keterlambatan admin dalam memproses pajak', 'MKS', 'KN', 'CHI4321897'),
('CD038', 'Ongoing', 'Penyalahgunaan dana publik', 'PLB', 'PP', 'CHI7584129'),
('CD039', 'Closed', 'Petugas menilang tanpa adanya surat tilang', 'BPN', 'KP', 'CHI1247890'),
('CD040', 'Ongoing', 'Korupsi dana bantuan bencana', 'DPS', 'PP', 'CHI3052871'),
('CD041', 'Closed', 'Penyelewengan dalam menangani kasus anak pegawai pemerintah', 'JKT', 'PP', 'CHI6194783'),
('CD042', 'Ongoing', 'Polisi meminta uang damai', 'SBY', 'KP', 'CHI8571439'),
('CD043', 'Closed', 'Keterbatasan Fasilitas', 'BDO', 'PK', 'CHI3926184'),
('CD044', 'Ongoing', 'Keterlambatan dalam pembuatan SIM', 'JKT', 'LP', 'CHI5741039'),
('CD045', 'Closed', 'Keterlambatan admin dalam memproses pajak', 'JKT', 'KN', 'CHI9284617'),
('CD046', 'Ongoing', 'Keterlambatan Proses Perizinan Usaha', 'SMG', 'PU', 'CHI6347210'),
('CD047', 'Closed', 'Keterlambatan Transportasi Umum', 'JKT', 'LP', 'CHI8704953'),
('CD048', 'Ongoing', 'Keterlambatan dalam pencetakan SIM', 'PLB', 'LP', 'CHI5134782'),
('CD049', 'Closed', 'Kurangnya Fasilitas dan Perawatan Transportasi Umum', 'BPN', 'TU', 'CHI2498351'),
('CD050', 'Ongoing', 'Kurangnya Transparansi Persyaratan Perizinan', 'JKT', 'PU', 'CHI6718903');

-- --------------------------------------------------------

--
-- Table structure for table `complainheader`
--

CREATE TABLE `complainheader` (
  `ComplainHeader_ID` char(10) NOT NULL,
  `Pegawai_ID` char(5) NOT NULL,
  `NIK` char(16) NOT NULL,
  `Tanggal_Daftar` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `complainheader`
--

INSERT INTO `complainheader` (`ComplainHeader_ID`, `Pegawai_ID`, `NIK`, `Tanggal_Daftar`) VALUES
('CHI1247890', 'IP009', '7556220809815670', '2024-04-26'),
('CHI1592437', 'IP006', '3406672912345670', '2023-12-16'),
('CHI1958743', 'IP017', '7323251507845670', '2024-01-29'),
('CHI1964237', 'IP006', '3656282201991230', '2024-04-14'),
('CHI2103487', 'IP002', '3555290811765670', '2024-03-29'),
('CHI2489371', 'IP010', '6310649112345670', '2024-01-01'),
('CHI2491873', 'IP027', '7342141203765670', '2024-03-09'),
('CHI2498351', 'IP019', '7514574812345670', '2024-06-05'),
('CHI3052871', 'IP010', '3657211503955670', '2024-04-30'),
('CHI3150728', 'IP030', '6344150107925670', '2024-03-21'),
('CHI3182674', 'IP013', '3226083104981230', '2024-01-13'),
('CHI3187402', 'IP021', '3630061103915670', '2024-02-14'),
('CHI3618947', 'IP025', '1244201001955670', '2024-03-01'),
('CHI3849052', 'IP001', '3601120412345670', '2023-11-26'),
('CHI3926184', 'IP013', '3206451712345670', '2024-05-12'),
('CHI4321897', 'IP007', '7356211009895670', '2024-04-18'),
('CHI4359172', 'IP008', '1708103912345670', '2023-12-24'),
('CHI4681253', 'IP029', '7544164712345670', '2024-03-17'),
('CHI4872051', 'IP015', '1222180112765670', '2024-01-21'),
('CHI5028316', 'IP020', '6322232609845670', '2024-02-10'),
('CHI5038172', 'IP003', '3215021406931230', '2023-12-04'),
('CHI5134782', 'IP018', '1712544312345670', '2024-06-01'),
('CHI5392176', 'IP003', '3256250603781230', '2024-04-02'),
('CHI5741039', 'IP001', '3608012312345670', '2024-05-16'),
('CHI5748092', 'IP012', '3522251001975670', '2024-01-09'),
('CHI5836741', 'IP024', '3335202509975670', '2024-02-26'),
('CHI6103728', 'IP011', '3602230512345670', '2024-01-05'),
('CHI6194783', 'IP011', '3604450712345670', '2024-05-04'),
('CHI6347210', 'IP016', '3409903212345670', '2024-05-24'),
('CHI6391748', 'IP018', '1723271108765670', '2024-02-02'),
('CHI6473102', 'IP022', '3544172609905670', '2024-02-18'),
('CHI6718294', 'IP002', '3502670912345670', '2023-11-30'),
('CHI6718903', 'IP001', '3614089512345670', '2024-06-09'),
('CHI6829154', 'IP004', '3357213004965670', '2024-04-06'),
('CHI6971823', 'IP009', '7510134412345670', '2023-12-28'),
('CHI7038251', 'IP028', '1744130401845670', '2024-03-13'),
('CHI7264810', 'IP016', '3424271208821230', '2024-01-25'),
('CHI7482103', 'IP005', '1205122412345670', '2023-12-12'),
('CHI7584129', 'IP008', '1755202709955670', '2024-04-22'),
('CHI7853419', 'IP026', '3441143006981230', '2024-03-05'),
('CHI8023641', 'IP007', '7307123412345670', '2023-12-20'),
('CHI8472139', 'IP005', '1256132306925670', '2024-04-10'),
('CHI8571439', 'IP012', '3505011312345670', '2024-05-08'),
('CHI8704953', 'IP011', '3611563812345670', '2024-05-28'),
('CHI8741032', 'IP001', '3642142205665670', '2024-03-25'),
('CHI8741203', 'IP019', '7521244512345670', '2024-02-06'),
('CHI9204853', 'IP023', '3237170908801230', '2024-02-22'),
('CHI9264871', 'IP004', '3304671912345670', '2023-12-08'),
('CHI9284617', 'IP021', '3609562812345670', '2024-05-20'),
('CHI9326178', 'IP014', '3323230412845670', '2024-01-17');

-- --------------------------------------------------------

--
-- Stand-in structure for view `denpasar`
-- (See below for the actual view)
--
CREATE TABLE `denpasar` (
`ComplainHeader_ID` char(10)
,`NIK` char(16)
,`Nama_Kategori` varchar(255)
,`Keterangan` varchar(255)
,`Status` varchar(50)
,`Branch_ID` char(3)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `jakarta`
-- (See below for the actual view)
--
CREATE TABLE `jakarta` (
`ComplainHeader_ID` char(10)
,`NIK` char(16)
,`Nama_Kategori` varchar(255)
,`Keterangan` varchar(255)
,`Status` varchar(50)
,`Branch_ID` char(3)
);

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `Kategori_ID` char(2) NOT NULL,
  `Nama_Kategori` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`Kategori_ID`, `Nama_Kategori`) VALUES
('BP', 'Biaya Pelayanan'),
('KN', 'Kualitas Pelayanan'),
('KP', 'Ketidakpatuhan Prosedur'),
('LP', 'Lambatnya Pelayanan'),
('PK', 'Pelayanan Kesehatan'),
('PP', 'Penyelewengan Penanganan'),
('PU', 'Perizinan Usaha'),
('PW', 'Penyalahgunaan Wewenang'),
('TP', 'Tindakan Petugas'),
('TU', 'Transportasi Umum');

-- --------------------------------------------------------

--
-- Stand-in structure for view `ketidakpatuhan_prosedur`
-- (See below for the actual view)
--
CREATE TABLE `ketidakpatuhan_prosedur` (
`Kota` varchar(255)
,`ComplainHeader_ID` char(10)
,`NIK` char(16)
,`Nama_Kategori` varchar(255)
,`Keterangan` varchar(255)
,`Status` varchar(50)
,`Tanggal_Daftar` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `kualitas_pelayanan`
-- (See below for the actual view)
--
CREATE TABLE `kualitas_pelayanan` (
`Kota` varchar(255)
,`ComplainHeader_ID` char(10)
,`NIK` char(16)
,`Nama_Kategori` varchar(255)
,`Keterangan` varchar(255)
,`Status` varchar(50)
,`Tanggal_Daftar` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `lambatnya_pelayanan`
-- (See below for the actual view)
--
CREATE TABLE `lambatnya_pelayanan` (
`Kota` varchar(255)
,`ComplainHeader_ID` char(10)
,`NIK` char(16)
,`Nama_Kategori` varchar(255)
,`Keterangan` varchar(255)
,`Status` varchar(50)
,`Tanggal_Daftar` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `makassar`
-- (See below for the actual view)
--
CREATE TABLE `makassar` (
`ComplainHeader_ID` char(10)
,`NIK` char(16)
,`Nama_Kategori` varchar(255)
,`Keterangan` varchar(255)
,`Status` varchar(50)
,`Branch_ID` char(3)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `medan`
-- (See below for the actual view)
--
CREATE TABLE `medan` (
`ComplainHeader_ID` char(10)
,`NIK` char(16)
,`Nama_Kategori` varchar(255)
,`Keterangan` varchar(255)
,`Status` varchar(50)
,`Branch_ID` char(3)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `palembang`
-- (See below for the actual view)
--
CREATE TABLE `palembang` (
`ComplainHeader_ID` char(10)
,`NIK` char(16)
,`Nama_Kategori` varchar(255)
,`Keterangan` varchar(255)
,`Status` varchar(50)
,`Branch_ID` char(3)
);

-- --------------------------------------------------------

--
-- Table structure for table `pegawai`
--

CREATE TABLE `pegawai` (
  `Pegawai_ID` char(5) NOT NULL,
  `Branch_ID` char(3) NOT NULL,
  `NamaPegawai` varchar(255) NOT NULL,
  `Umur` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pegawai`
--

INSERT INTO `pegawai` (`Pegawai_ID`, `Branch_ID`, `NamaPegawai`, `Umur`) VALUES
('IP001', 'JKT', 'Yanti Setiawan', 28),
('IP002', 'SBY', 'Indra Kusuma', 35),
('IP003', 'BDO', 'Rina Wijaya', 42),
('IP004', 'YGY', 'Budi Santoso', 30),
('IP005', 'MDN', 'Sari Indah', 25),
('IP006', 'SMG', 'Dika Pratama', 38),
('IP007', 'MKS', 'Lia Rahayu', 33),
('IP008', 'PLB', 'Adi Nugraha', 29),
('IP009', 'BPN', 'Maya Putri', 40),
('IP010', 'DPS', 'Rizky Wulandari', 31),
('IP011', 'JKT', 'Irfan Saputra', 27),
('IP012', 'SBY', 'Dewi Rahmawati', 34),
('IP013', 'BDO', 'Fahmi Santoso', 41),
('IP014', 'YGY', 'Nita Permata', 29),
('IP015', 'MDN', 'Eko Prasetyo', 24),
('IP016', 'SMG', 'Citra Maulana', 37),
('IP017', 'MKS', 'Rini Kartika', 32),
('IP018', 'PLB', 'Bambang Wijaya', 28),
('IP019', 'BPN', 'Novi Fitriani', 39),
('IP020', 'DPS', 'Yanto Susanto', 30),
('IP021', 'JKT', 'Desi Permadi', 26),
('IP022', 'SBY', 'Faisal Rahman', 33),
('IP023', 'BDO', 'Erna Setiawan', 40),
('IP024', 'YGY', 'Rudi Hidayat', 28),
('IP025', 'MDN', 'Fitriani Sari', 23),
('IP026', 'SMG', 'Dedi Saputra', 36),
('IP027', 'MKS', 'Irma Novianti', 31),
('IP028', 'PLB', 'Dian Prasetya', 27),
('IP029', 'BPN', 'Dini Nurul', 38),
('IP030', 'DPS', 'Hadi Purnomo', 29);

-- --------------------------------------------------------

--
-- Stand-in structure for view `pelayanan_kesehatan`
-- (See below for the actual view)
--
CREATE TABLE `pelayanan_kesehatan` (
`Kota` varchar(255)
,`ComplainHeader_ID` char(10)
,`NIK` char(16)
,`Nama_Kategori` varchar(255)
,`Keterangan` varchar(255)
,`Status` varchar(50)
,`Tanggal_Daftar` date
);

-- --------------------------------------------------------

--
-- Table structure for table `penduduk`
--

CREATE TABLE `penduduk` (
  `NIK` char(16) NOT NULL,
  `Nama` varchar(255) NOT NULL,
  `Umur` int(11) NOT NULL,
  `Kota` varchar(255) NOT NULL,
  `Alamat` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `penduduk`
--

INSERT INTO `penduduk` (`NIK`, `Nama`, `Umur`, `Kota`, `Alamat`) VALUES
('1205122412345670', 'Faisal Rahman', 29, 'Medan', 'Jl. Melati No. 27'),
('1222180112765670', 'Fira Maulana', 27, 'Medan', 'Jl. Cempaka Putih No. 7'),
('1244201001955670', 'Irma Novianti', 40, 'Medan', 'Jl. Melati Sejahtera No. 22'),
('1256132306925670', 'Rizky Wulandari', 36, 'Medan', 'Jl. Bahagia Indah No. 12'),
('1708103912345670', 'Rina Wijaya', 32, 'Palembang', 'Jl. Flamboyan No. 42'),
('1712544312345670', 'Nanda Maulana', 51, 'Palembang', 'Jl. Anggrek Asri No. 19'),
('1723271108765670', 'Andi Kusuma', 25, 'Palembang', 'Jl. Mawar Hijau No. 16'),
('1744130401845670', 'Nita Permata', 30, 'Palembang', 'Jl. Puspa Ceria No. 26'),
('1755202709955670', 'Nisa Fitri', 33, 'Palembang', 'Jl. Anggrek Ceria No. 24'),
('3206451712345670', 'Yuda Pratama', 34, 'Bandung', 'Jl. Kenanga Mawar No. 43'),
('3215021406931230', 'Budi Santoso', 47, 'Bandung', 'Jl. Dahlia No. 33'),
('3226083104981230', 'Adi Nugraha', 27, 'Bandung', 'Jl. Indah No. 17'),
('3237170908801230', 'Dewi Rahmawati', 27, 'Bandung', 'Jl. Bahagia Sejahtera No. 20'),
('3256250603781230', 'Desi Permadi', 35, 'Bandung', 'Jl. Sejahtera Mawar No. 34'),
('3304671912345670', 'Siti Nurhayati', 47, 'Yogyakarta', 'Jl. Cendana No. 8'),
('3323230412845670', 'Yanti Setiawan', 41, 'Yogyakarta', 'Jl. Puspa Hijau No. 28'),
('3335202509975670', 'Dedi Saputra', 28, 'Yogyakarta', 'Jl. Damai Asri No. 38'),
('3357213004965670', 'Dini Nurul', 33, 'Yogyakarta', 'Jl. Indah Ceria No. 21'),
('3406672912345670', 'Anisa Permata', 46, 'Semarang', 'Jl. Ceria No. 14'),
('3409903212345670', 'Asti Wijaya', 31, 'Semarang', 'Jl. Sejahtera Ceria No. 45'),
('3424271208821230', 'Dika Pratama', 44, 'Semarang', 'Jl. Kenanga Indah No. 44'),
('3441143006981230', 'Sari Indah', 22, 'Semarang', 'Jl. Harmoni Cendana No. 35'),
('3502670912345670', 'Fitri Indah', 43, 'Surabaya', 'Jl. Kenanga No. 15'),
('3505011312345670', 'Nina Sari', 24, 'Surabaya', 'Jl. Ceria Sejahtera No. 27'),
('3522251001975670', 'Maya Putri', 39, 'Surabaya', 'Jl. Damai No. 23'),
('3544172609905670', 'Rudi Hidayat', 56, 'Surabaya', 'Jl. Sejahtera Indah No. 13'),
('3555290811765670', 'Yanto Susanto', 35, 'Surabaya', 'Jl. Puspa Harmoni No. 6'),
('3601120412345670', 'Muhammad Arief', 51, 'Jakarta', 'Jl. Mawar No. 21'),
('3602230512345670', 'Irfan Saputra', 40, 'Jakarta', 'Jl. Bahagia No. 11'),
('3604450712345670', 'Dino Nugroho', 42, 'Jakarta', 'Jl. Puspa Indah No. 14'),
('3608012312345670', 'Lina Kartika', 46, 'Jakarta', 'Jl. Dahlia Cendana No. 17'),
('3609562812345670', 'Yoga Permadi', 26, 'Jakarta', 'Jl. Bahagia Hijau No. 33'),
('3611563812345670', 'Roni Saputra', 31, 'Jakarta', 'Jl. Melati Indah No. 8'),
('3614089512345670', 'Reza Nugroho', 30, 'Jakarta', 'Jl. Damai Ceria No. 15'),
('3630061103915670', 'Citra Maulana', 26, 'Jakarta', 'Jl. Ceria Mawar No. 37'),
('3642142205665670', 'Rini Kartika', 46, 'Jakarta', 'Jl. Mawar Cendana No. 40'),
('3656282201991230', 'Fika Rahmawati', 35, 'Jakarta', 'Jl. Dahlia Sejahtera No. 30'),
('3657211503955670', 'Fina Putri', 53, 'Jakarta', 'Jl. Flamboyan Asri No. 32'),
('6310649112345670', 'Novi Fitriani', 33, 'Denpasar', 'Jl. Sejahtera No. 36'),
('6322232609845670', 'Bambang Wijaya', 47, 'Denpasar', 'Jl. Puspa Cendana No. 9'),
('6344150107925670', 'Hadi Purnomo', 35, 'Denpasar', 'Jl. Kenanga Ceria No. 29'),
('7307123412345670', 'Dian Prasetyo', 40, 'Makassar', 'Jl. Harmoni No. 19'),
('7323251507845670', 'Erna Setiawan', 56, 'Makassar', 'Jl. Anggrek Sejahtera No. 31'),
('7342141203765670', 'Fahmi Santoso', 27, 'Makassar', 'Jl. Flamboyan Indah No. 10'),
('7356211009895670', 'Dicky Prasetya', 53, 'Makassar', 'Jl. Cempaka Harmoni No. 41'),
('7510134412345670', 'Heri Susanto', 45, 'Balikpapan', 'Jl. Puspa No. 5'),
('7514574812345670', 'Sinta Pratiwi', 28, 'Balikpapan', 'Jl. Puspa Hijau No. 46'),
('7521244512345670', 'Lia Rahayu', 28, 'Balikpapan', 'Jl. Dahlia Indah No. 25'),
('7544164712345670', 'Eko Prasetyo', 37, 'Balikpapan', 'Jl. Cendana Asri No. 18'),
('7556220809815670', 'Dani Saputra', 55, 'Balikpapan', 'Jl. Melati Harmoni No. 39');

-- --------------------------------------------------------

--
-- Stand-in structure for view `penyalahgunaan_wewenang`
-- (See below for the actual view)
--
CREATE TABLE `penyalahgunaan_wewenang` (
`Kota` varchar(255)
,`ComplainHeader_ID` char(10)
,`NIK` char(16)
,`Nama_Kategori` varchar(255)
,`Keterangan` varchar(255)
,`Status` varchar(50)
,`Tanggal_Daftar` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `penyelewengan_penanganan`
-- (See below for the actual view)
--
CREATE TABLE `penyelewengan_penanganan` (
`Kota` varchar(255)
,`ComplainHeader_ID` char(10)
,`NIK` char(16)
,`Nama_Kategori` varchar(255)
,`Keterangan` varchar(255)
,`Status` varchar(50)
,`Tanggal_Daftar` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `perizinan_usaha`
-- (See below for the actual view)
--
CREATE TABLE `perizinan_usaha` (
`Kota` varchar(255)
,`ComplainHeader_ID` char(10)
,`NIK` char(16)
,`Nama_Kategori` varchar(255)
,`Keterangan` varchar(255)
,`Status` varchar(50)
,`Tanggal_Daftar` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `semarang`
-- (See below for the actual view)
--
CREATE TABLE `semarang` (
`ComplainHeader_ID` char(10)
,`NIK` char(16)
,`Nama_Kategori` varchar(255)
,`Keterangan` varchar(255)
,`Status` varchar(50)
,`Branch_ID` char(3)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `surabaya`
-- (See below for the actual view)
--
CREATE TABLE `surabaya` (
`ComplainHeader_ID` char(10)
,`NIK` char(16)
,`Nama_Kategori` varchar(255)
,`Keterangan` varchar(255)
,`Status` varchar(50)
,`Branch_ID` char(3)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `tindakan_petugas`
-- (See below for the actual view)
--
CREATE TABLE `tindakan_petugas` (
`Kota` varchar(255)
,`ComplainHeader_ID` char(10)
,`NIK` char(16)
,`Nama_Kategori` varchar(255)
,`Keterangan` varchar(255)
,`Status` varchar(50)
,`Tanggal_Daftar` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `transportasi_umum`
-- (See below for the actual view)
--
CREATE TABLE `transportasi_umum` (
`Kota` varchar(255)
,`ComplainHeader_ID` char(10)
,`NIK` char(16)
,`Nama_Kategori` varchar(255)
,`Keterangan` varchar(255)
,`Status` varchar(50)
,`Tanggal_Daftar` date
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `yogyakarta`
-- (See below for the actual view)
--
CREATE TABLE `yogyakarta` (
`ComplainHeader_ID` char(10)
,`NIK` char(16)
,`Nama_Kategori` varchar(255)
,`Keterangan` varchar(255)
,`Status` varchar(50)
,`Branch_ID` char(3)
);

-- --------------------------------------------------------

--
-- Structure for view `balikpapan`
--
DROP TABLE IF EXISTS `balikpapan`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `balikpapan`  AS SELECT `complainheader`.`ComplainHeader_ID` AS `ComplainHeader_ID`, `complainheader`.`NIK` AS `NIK`, `kategori`.`Nama_Kategori` AS `Nama_Kategori`, `complaindetail`.`Keterangan` AS `Keterangan`, `complaindetail`.`Status` AS `Status`, `complaindetail`.`Branch_ID` AS `Branch_ID` FROM ((((`complainheader` join `complaindetail` on(`complainheader`.`ComplainHeader_ID` = `complaindetail`.`ComplainHeader_ID`)) join `penduduk` on(`complainheader`.`NIK` = `penduduk`.`NIK`)) join `kategori` on(`complaindetail`.`Kategori_ID` = `kategori`.`Kategori_ID`)) join `branch` on(`complaindetail`.`Branch_ID` = `branch`.`Branch_ID`)) WHERE `complaindetail`.`Branch_ID` like 'BPN' ;

-- --------------------------------------------------------

--
-- Structure for view `bandung`
--
DROP TABLE IF EXISTS `bandung`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `bandung`  AS SELECT `complainheader`.`ComplainHeader_ID` AS `ComplainHeader_ID`, `complainheader`.`NIK` AS `NIK`, `kategori`.`Nama_Kategori` AS `Nama_Kategori`, `complaindetail`.`Keterangan` AS `Keterangan`, `complaindetail`.`Status` AS `Status`, `complaindetail`.`Branch_ID` AS `Branch_ID` FROM ((((`complainheader` join `complaindetail` on(`complainheader`.`ComplainHeader_ID` = `complaindetail`.`ComplainHeader_ID`)) join `penduduk` on(`complainheader`.`NIK` = `penduduk`.`NIK`)) join `kategori` on(`complaindetail`.`Kategori_ID` = `kategori`.`Kategori_ID`)) join `branch` on(`complaindetail`.`Branch_ID` = `branch`.`Branch_ID`)) WHERE `complaindetail`.`Branch_ID` like 'BDO' ;

-- --------------------------------------------------------

--
-- Structure for view `biaya_pelayanan`
--
DROP TABLE IF EXISTS `biaya_pelayanan`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `biaya_pelayanan`  AS SELECT `branch`.`Kota` AS `Kota`, `complainheader`.`ComplainHeader_ID` AS `ComplainHeader_ID`, `complainheader`.`NIK` AS `NIK`, `kategori`.`Nama_Kategori` AS `Nama_Kategori`, `complaindetail`.`Keterangan` AS `Keterangan`, `complaindetail`.`Status` AS `Status`, `complainheader`.`Tanggal_Daftar` AS `Tanggal_Daftar` FROM ((((`complainheader` join `complaindetail` on(`complainheader`.`ComplainHeader_ID` = `complaindetail`.`ComplainHeader_ID`)) join `penduduk` on(`complainheader`.`NIK` = `penduduk`.`NIK`)) join `kategori` on(`complaindetail`.`Kategori_ID` = `kategori`.`Kategori_ID`)) join `branch` on(`complaindetail`.`Branch_ID` = `branch`.`Branch_ID`)) WHERE `complaindetail`.`Kategori_ID` like 'BP' ;

-- --------------------------------------------------------

--
-- Structure for view `denpasar`
--
DROP TABLE IF EXISTS `denpasar`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `denpasar`  AS SELECT `complainheader`.`ComplainHeader_ID` AS `ComplainHeader_ID`, `complainheader`.`NIK` AS `NIK`, `kategori`.`Nama_Kategori` AS `Nama_Kategori`, `complaindetail`.`Keterangan` AS `Keterangan`, `complaindetail`.`Status` AS `Status`, `complaindetail`.`Branch_ID` AS `Branch_ID` FROM ((((`complainheader` join `complaindetail` on(`complainheader`.`ComplainHeader_ID` = `complaindetail`.`ComplainHeader_ID`)) join `penduduk` on(`complainheader`.`NIK` = `penduduk`.`NIK`)) join `kategori` on(`complaindetail`.`Kategori_ID` = `kategori`.`Kategori_ID`)) join `branch` on(`complaindetail`.`Branch_ID` = `branch`.`Branch_ID`)) WHERE `complaindetail`.`Branch_ID` like 'DPS' ;

-- --------------------------------------------------------

--
-- Structure for view `jakarta`
--
DROP TABLE IF EXISTS `jakarta`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `jakarta`  AS SELECT `complainheader`.`ComplainHeader_ID` AS `ComplainHeader_ID`, `complainheader`.`NIK` AS `NIK`, `kategori`.`Nama_Kategori` AS `Nama_Kategori`, `complaindetail`.`Keterangan` AS `Keterangan`, `complaindetail`.`Status` AS `Status`, `complaindetail`.`Branch_ID` AS `Branch_ID` FROM ((((`complainheader` join `complaindetail` on(`complainheader`.`ComplainHeader_ID` = `complaindetail`.`ComplainHeader_ID`)) join `penduduk` on(`complainheader`.`NIK` = `penduduk`.`NIK`)) join `kategori` on(`complaindetail`.`Kategori_ID` = `kategori`.`Kategori_ID`)) join `branch` on(`complaindetail`.`Branch_ID` = `branch`.`Branch_ID`)) WHERE `complaindetail`.`Branch_ID` like 'JKT' ;

-- --------------------------------------------------------

--
-- Structure for view `ketidakpatuhan_prosedur`
--
DROP TABLE IF EXISTS `ketidakpatuhan_prosedur`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `ketidakpatuhan_prosedur`  AS SELECT `branch`.`Kota` AS `Kota`, `complainheader`.`ComplainHeader_ID` AS `ComplainHeader_ID`, `complainheader`.`NIK` AS `NIK`, `kategori`.`Nama_Kategori` AS `Nama_Kategori`, `complaindetail`.`Keterangan` AS `Keterangan`, `complaindetail`.`Status` AS `Status`, `complainheader`.`Tanggal_Daftar` AS `Tanggal_Daftar` FROM ((((`complainheader` join `complaindetail` on(`complainheader`.`ComplainHeader_ID` = `complaindetail`.`ComplainHeader_ID`)) join `penduduk` on(`complainheader`.`NIK` = `penduduk`.`NIK`)) join `kategori` on(`complaindetail`.`Kategori_ID` = `kategori`.`Kategori_ID`)) join `branch` on(`complaindetail`.`Branch_ID` = `branch`.`Branch_ID`)) WHERE `complaindetail`.`Kategori_ID` like 'KP' ;

-- --------------------------------------------------------

--
-- Structure for view `kualitas_pelayanan`
--
DROP TABLE IF EXISTS `kualitas_pelayanan`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `kualitas_pelayanan`  AS SELECT `branch`.`Kota` AS `Kota`, `complainheader`.`ComplainHeader_ID` AS `ComplainHeader_ID`, `complainheader`.`NIK` AS `NIK`, `kategori`.`Nama_Kategori` AS `Nama_Kategori`, `complaindetail`.`Keterangan` AS `Keterangan`, `complaindetail`.`Status` AS `Status`, `complainheader`.`Tanggal_Daftar` AS `Tanggal_Daftar` FROM ((((`complainheader` join `complaindetail` on(`complainheader`.`ComplainHeader_ID` = `complaindetail`.`ComplainHeader_ID`)) join `penduduk` on(`complainheader`.`NIK` = `penduduk`.`NIK`)) join `kategori` on(`complaindetail`.`Kategori_ID` = `kategori`.`Kategori_ID`)) join `branch` on(`complaindetail`.`Branch_ID` = `branch`.`Branch_ID`)) WHERE `complaindetail`.`Kategori_ID` like 'KN' ;

-- --------------------------------------------------------

--
-- Structure for view `lambatnya_pelayanan`
--
DROP TABLE IF EXISTS `lambatnya_pelayanan`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `lambatnya_pelayanan`  AS SELECT `branch`.`Kota` AS `Kota`, `complainheader`.`ComplainHeader_ID` AS `ComplainHeader_ID`, `complainheader`.`NIK` AS `NIK`, `kategori`.`Nama_Kategori` AS `Nama_Kategori`, `complaindetail`.`Keterangan` AS `Keterangan`, `complaindetail`.`Status` AS `Status`, `complainheader`.`Tanggal_Daftar` AS `Tanggal_Daftar` FROM ((((`complainheader` join `complaindetail` on(`complainheader`.`ComplainHeader_ID` = `complaindetail`.`ComplainHeader_ID`)) join `penduduk` on(`complainheader`.`NIK` = `penduduk`.`NIK`)) join `kategori` on(`complaindetail`.`Kategori_ID` = `kategori`.`Kategori_ID`)) join `branch` on(`complaindetail`.`Branch_ID` = `branch`.`Branch_ID`)) WHERE `complaindetail`.`Kategori_ID` like 'LP' ;

-- --------------------------------------------------------

--
-- Structure for view `makassar`
--
DROP TABLE IF EXISTS `makassar`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `makassar`  AS SELECT `complainheader`.`ComplainHeader_ID` AS `ComplainHeader_ID`, `complainheader`.`NIK` AS `NIK`, `kategori`.`Nama_Kategori` AS `Nama_Kategori`, `complaindetail`.`Keterangan` AS `Keterangan`, `complaindetail`.`Status` AS `Status`, `complaindetail`.`Branch_ID` AS `Branch_ID` FROM ((((`complainheader` join `complaindetail` on(`complainheader`.`ComplainHeader_ID` = `complaindetail`.`ComplainHeader_ID`)) join `penduduk` on(`complainheader`.`NIK` = `penduduk`.`NIK`)) join `kategori` on(`complaindetail`.`Kategori_ID` = `kategori`.`Kategori_ID`)) join `branch` on(`complaindetail`.`Branch_ID` = `branch`.`Branch_ID`)) WHERE `complaindetail`.`Branch_ID` like 'MKS' ;

-- --------------------------------------------------------

--
-- Structure for view `medan`
--
DROP TABLE IF EXISTS `medan`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `medan`  AS SELECT `complainheader`.`ComplainHeader_ID` AS `ComplainHeader_ID`, `complainheader`.`NIK` AS `NIK`, `kategori`.`Nama_Kategori` AS `Nama_Kategori`, `complaindetail`.`Keterangan` AS `Keterangan`, `complaindetail`.`Status` AS `Status`, `complaindetail`.`Branch_ID` AS `Branch_ID` FROM ((((`complainheader` join `complaindetail` on(`complainheader`.`ComplainHeader_ID` = `complaindetail`.`ComplainHeader_ID`)) join `penduduk` on(`complainheader`.`NIK` = `penduduk`.`NIK`)) join `kategori` on(`complaindetail`.`Kategori_ID` = `kategori`.`Kategori_ID`)) join `branch` on(`complaindetail`.`Branch_ID` = `branch`.`Branch_ID`)) WHERE `complaindetail`.`Branch_ID` like 'MDN' ;

-- --------------------------------------------------------

--
-- Structure for view `palembang`
--
DROP TABLE IF EXISTS `palembang`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `palembang`  AS SELECT `complainheader`.`ComplainHeader_ID` AS `ComplainHeader_ID`, `complainheader`.`NIK` AS `NIK`, `kategori`.`Nama_Kategori` AS `Nama_Kategori`, `complaindetail`.`Keterangan` AS `Keterangan`, `complaindetail`.`Status` AS `Status`, `complaindetail`.`Branch_ID` AS `Branch_ID` FROM ((((`complainheader` join `complaindetail` on(`complainheader`.`ComplainHeader_ID` = `complaindetail`.`ComplainHeader_ID`)) join `penduduk` on(`complainheader`.`NIK` = `penduduk`.`NIK`)) join `kategori` on(`complaindetail`.`Kategori_ID` = `kategori`.`Kategori_ID`)) join `branch` on(`complaindetail`.`Branch_ID` = `branch`.`Branch_ID`)) WHERE `complaindetail`.`Branch_ID` like 'PLB' ;

-- --------------------------------------------------------

--
-- Structure for view `pelayanan_kesehatan`
--
DROP TABLE IF EXISTS `pelayanan_kesehatan`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `pelayanan_kesehatan`  AS SELECT `branch`.`Kota` AS `Kota`, `complainheader`.`ComplainHeader_ID` AS `ComplainHeader_ID`, `complainheader`.`NIK` AS `NIK`, `kategori`.`Nama_Kategori` AS `Nama_Kategori`, `complaindetail`.`Keterangan` AS `Keterangan`, `complaindetail`.`Status` AS `Status`, `complainheader`.`Tanggal_Daftar` AS `Tanggal_Daftar` FROM ((((`complainheader` join `complaindetail` on(`complainheader`.`ComplainHeader_ID` = `complaindetail`.`ComplainHeader_ID`)) join `penduduk` on(`complainheader`.`NIK` = `penduduk`.`NIK`)) join `kategori` on(`complaindetail`.`Kategori_ID` = `kategori`.`Kategori_ID`)) join `branch` on(`complaindetail`.`Branch_ID` = `branch`.`Branch_ID`)) WHERE `complaindetail`.`Kategori_ID` like 'PK' ;

-- --------------------------------------------------------

--
-- Structure for view `penyalahgunaan_wewenang`
--
DROP TABLE IF EXISTS `penyalahgunaan_wewenang`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `penyalahgunaan_wewenang`  AS SELECT `branch`.`Kota` AS `Kota`, `complainheader`.`ComplainHeader_ID` AS `ComplainHeader_ID`, `complainheader`.`NIK` AS `NIK`, `kategori`.`Nama_Kategori` AS `Nama_Kategori`, `complaindetail`.`Keterangan` AS `Keterangan`, `complaindetail`.`Status` AS `Status`, `complainheader`.`Tanggal_Daftar` AS `Tanggal_Daftar` FROM ((((`complainheader` join `complaindetail` on(`complainheader`.`ComplainHeader_ID` = `complaindetail`.`ComplainHeader_ID`)) join `penduduk` on(`complainheader`.`NIK` = `penduduk`.`NIK`)) join `kategori` on(`complaindetail`.`Kategori_ID` = `kategori`.`Kategori_ID`)) join `branch` on(`complaindetail`.`Branch_ID` = `branch`.`Branch_ID`)) WHERE `complaindetail`.`Kategori_ID` like 'PW' ;

-- --------------------------------------------------------

--
-- Structure for view `penyelewengan_penanganan`
--
DROP TABLE IF EXISTS `penyelewengan_penanganan`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `penyelewengan_penanganan`  AS SELECT `branch`.`Kota` AS `Kota`, `complainheader`.`ComplainHeader_ID` AS `ComplainHeader_ID`, `complainheader`.`NIK` AS `NIK`, `kategori`.`Nama_Kategori` AS `Nama_Kategori`, `complaindetail`.`Keterangan` AS `Keterangan`, `complaindetail`.`Status` AS `Status`, `complainheader`.`Tanggal_Daftar` AS `Tanggal_Daftar` FROM ((((`complainheader` join `complaindetail` on(`complainheader`.`ComplainHeader_ID` = `complaindetail`.`ComplainHeader_ID`)) join `penduduk` on(`complainheader`.`NIK` = `penduduk`.`NIK`)) join `kategori` on(`complaindetail`.`Kategori_ID` = `kategori`.`Kategori_ID`)) join `branch` on(`complaindetail`.`Branch_ID` = `branch`.`Branch_ID`)) WHERE `complaindetail`.`Kategori_ID` like 'PP' ;

-- --------------------------------------------------------

--
-- Structure for view `perizinan_usaha`
--
DROP TABLE IF EXISTS `perizinan_usaha`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `perizinan_usaha`  AS SELECT `branch`.`Kota` AS `Kota`, `complainheader`.`ComplainHeader_ID` AS `ComplainHeader_ID`, `complainheader`.`NIK` AS `NIK`, `kategori`.`Nama_Kategori` AS `Nama_Kategori`, `complaindetail`.`Keterangan` AS `Keterangan`, `complaindetail`.`Status` AS `Status`, `complainheader`.`Tanggal_Daftar` AS `Tanggal_Daftar` FROM ((((`complainheader` join `complaindetail` on(`complainheader`.`ComplainHeader_ID` = `complaindetail`.`ComplainHeader_ID`)) join `penduduk` on(`complainheader`.`NIK` = `penduduk`.`NIK`)) join `kategori` on(`complaindetail`.`Kategori_ID` = `kategori`.`Kategori_ID`)) join `branch` on(`complaindetail`.`Branch_ID` = `branch`.`Branch_ID`)) WHERE `complaindetail`.`Kategori_ID` like 'PU' ;

-- --------------------------------------------------------

--
-- Structure for view `semarang`
--
DROP TABLE IF EXISTS `semarang`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `semarang`  AS SELECT `complainheader`.`ComplainHeader_ID` AS `ComplainHeader_ID`, `complainheader`.`NIK` AS `NIK`, `kategori`.`Nama_Kategori` AS `Nama_Kategori`, `complaindetail`.`Keterangan` AS `Keterangan`, `complaindetail`.`Status` AS `Status`, `complaindetail`.`Branch_ID` AS `Branch_ID` FROM ((((`complainheader` join `complaindetail` on(`complainheader`.`ComplainHeader_ID` = `complaindetail`.`ComplainHeader_ID`)) join `penduduk` on(`complainheader`.`NIK` = `penduduk`.`NIK`)) join `kategori` on(`complaindetail`.`Kategori_ID` = `kategori`.`Kategori_ID`)) join `branch` on(`complaindetail`.`Branch_ID` = `branch`.`Branch_ID`)) WHERE `complaindetail`.`Branch_ID` like 'SMG' ;

-- --------------------------------------------------------

--
-- Structure for view `surabaya`
--
DROP TABLE IF EXISTS `surabaya`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `surabaya`  AS SELECT `complainheader`.`ComplainHeader_ID` AS `ComplainHeader_ID`, `complainheader`.`NIK` AS `NIK`, `kategori`.`Nama_Kategori` AS `Nama_Kategori`, `complaindetail`.`Keterangan` AS `Keterangan`, `complaindetail`.`Status` AS `Status`, `complaindetail`.`Branch_ID` AS `Branch_ID` FROM ((((`complainheader` join `complaindetail` on(`complainheader`.`ComplainHeader_ID` = `complaindetail`.`ComplainHeader_ID`)) join `penduduk` on(`complainheader`.`NIK` = `penduduk`.`NIK`)) join `kategori` on(`complaindetail`.`Kategori_ID` = `kategori`.`Kategori_ID`)) join `branch` on(`complaindetail`.`Branch_ID` = `branch`.`Branch_ID`)) WHERE `complaindetail`.`Branch_ID` like 'SBY' ;

-- --------------------------------------------------------

--
-- Structure for view `tindakan_petugas`
--
DROP TABLE IF EXISTS `tindakan_petugas`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `tindakan_petugas`  AS SELECT `branch`.`Kota` AS `Kota`, `complainheader`.`ComplainHeader_ID` AS `ComplainHeader_ID`, `complainheader`.`NIK` AS `NIK`, `kategori`.`Nama_Kategori` AS `Nama_Kategori`, `complaindetail`.`Keterangan` AS `Keterangan`, `complaindetail`.`Status` AS `Status`, `complainheader`.`Tanggal_Daftar` AS `Tanggal_Daftar` FROM ((((`complainheader` join `complaindetail` on(`complainheader`.`ComplainHeader_ID` = `complaindetail`.`ComplainHeader_ID`)) join `penduduk` on(`complainheader`.`NIK` = `penduduk`.`NIK`)) join `kategori` on(`complaindetail`.`Kategori_ID` = `kategori`.`Kategori_ID`)) join `branch` on(`complaindetail`.`Branch_ID` = `branch`.`Branch_ID`)) WHERE `complaindetail`.`Kategori_ID` like 'TP' ;

-- --------------------------------------------------------

--
-- Structure for view `transportasi_umum`
--
DROP TABLE IF EXISTS `transportasi_umum`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `transportasi_umum`  AS SELECT `branch`.`Kota` AS `Kota`, `complainheader`.`ComplainHeader_ID` AS `ComplainHeader_ID`, `complainheader`.`NIK` AS `NIK`, `kategori`.`Nama_Kategori` AS `Nama_Kategori`, `complaindetail`.`Keterangan` AS `Keterangan`, `complaindetail`.`Status` AS `Status`, `complainheader`.`Tanggal_Daftar` AS `Tanggal_Daftar` FROM ((((`complainheader` join `complaindetail` on(`complainheader`.`ComplainHeader_ID` = `complaindetail`.`ComplainHeader_ID`)) join `penduduk` on(`complainheader`.`NIK` = `penduduk`.`NIK`)) join `kategori` on(`complaindetail`.`Kategori_ID` = `kategori`.`Kategori_ID`)) join `branch` on(`complaindetail`.`Branch_ID` = `branch`.`Branch_ID`)) WHERE `complaindetail`.`Kategori_ID` like 'TU' ;

-- --------------------------------------------------------

--
-- Structure for view `yogyakarta`
--
DROP TABLE IF EXISTS `yogyakarta`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `yogyakarta`  AS SELECT `complainheader`.`ComplainHeader_ID` AS `ComplainHeader_ID`, `complainheader`.`NIK` AS `NIK`, `kategori`.`Nama_Kategori` AS `Nama_Kategori`, `complaindetail`.`Keterangan` AS `Keterangan`, `complaindetail`.`Status` AS `Status`, `complaindetail`.`Branch_ID` AS `Branch_ID` FROM ((((`complainheader` join `complaindetail` on(`complainheader`.`ComplainHeader_ID` = `complaindetail`.`ComplainHeader_ID`)) join `penduduk` on(`complainheader`.`NIK` = `penduduk`.`NIK`)) join `kategori` on(`complaindetail`.`Kategori_ID` = `kategori`.`Kategori_ID`)) join `branch` on(`complaindetail`.`Branch_ID` = `branch`.`Branch_ID`)) WHERE `complaindetail`.`Branch_ID` like 'YGY' ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
  ADD PRIMARY KEY (`Branch_ID`);

--
-- Indexes for table `complaindetail`
--
ALTER TABLE `complaindetail`
  ADD PRIMARY KEY (`ComplainDetail_ID`),
  ADD KEY `Branch_ID` (`Branch_ID`),
  ADD KEY `Kategori_ID` (`Kategori_ID`),
  ADD KEY `ComplainHeader_ID` (`ComplainHeader_ID`);

--
-- Indexes for table `complainheader`
--
ALTER TABLE `complainheader`
  ADD PRIMARY KEY (`ComplainHeader_ID`),
  ADD KEY `Pegawai_ID` (`Pegawai_ID`),
  ADD KEY `NIK` (`NIK`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`Kategori_ID`);

--
-- Indexes for table `pegawai`
--
ALTER TABLE `pegawai`
  ADD PRIMARY KEY (`Pegawai_ID`),
  ADD KEY `Branch_ID` (`Branch_ID`);

--
-- Indexes for table `penduduk`
--
ALTER TABLE `penduduk`
  ADD PRIMARY KEY (`NIK`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `complaindetail`
--
ALTER TABLE `complaindetail`
  ADD CONSTRAINT `complaindetail_ibfk_1` FOREIGN KEY (`Branch_ID`) REFERENCES `branch` (`Branch_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `complaindetail_ibfk_2` FOREIGN KEY (`Kategori_ID`) REFERENCES `kategori` (`Kategori_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `complaindetail_ibfk_3` FOREIGN KEY (`ComplainHeader_ID`) REFERENCES `complainheader` (`ComplainHeader_ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `complainheader`
--
ALTER TABLE `complainheader`
  ADD CONSTRAINT `complainheader_ibfk_1` FOREIGN KEY (`Pegawai_ID`) REFERENCES `pegawai` (`Pegawai_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `complainheader_ibfk_2` FOREIGN KEY (`NIK`) REFERENCES `penduduk` (`NIK`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pegawai`
--
ALTER TABLE `pegawai`
  ADD CONSTRAINT `pegawai_ibfk_1` FOREIGN KEY (`Branch_ID`) REFERENCES `branch` (`Branch_ID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
